
print("Welcome to the Python Fundamentals Bootcamp!")

