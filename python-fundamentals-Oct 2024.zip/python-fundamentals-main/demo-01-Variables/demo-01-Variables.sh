------------------------------------------------------------
Jupyter Notebooks
------------------------------------------------------------


# I have Jupyter notebooks installed on my machine

jupyter --version


jupyter notebook


# Show the notebooks home page

# Show that it is the same home page on the terminal

# Name the notebook "Variables"

# Switch to the terminal and show the notebook created


ls -l


# Show the kernel used on the top-right

# Explain the kernel

# NOTES:
# The Python kernel in a notebook is the computational engine that executes the code cells within the notebook, handling all the calculations, processing, and variable management. It allows interactive coding and provides real-time feedback

# Explain the idea of cells


# Show the menu options briefly

File

Edit

View

Insert

Cell 

Kernel







































